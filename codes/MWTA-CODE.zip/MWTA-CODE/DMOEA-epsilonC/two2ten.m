function x=two2ten(X,prob)
W=prob.W;T=prob.T;S=prob.S;
x=zeros(1,W*S); 
    for n=1:S
        for i=1:W
            for j=1:T
                if X(i,j+(n-1)*T)==1
                    x(1,i+(n-1)*W)=j;
                end
            end
        end
    end
end

