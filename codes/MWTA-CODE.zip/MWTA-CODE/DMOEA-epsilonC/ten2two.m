function X=ten2two(x,prob)
W=prob.W;T=prob.T;S=prob.S;
X=zeros(W,T*S);
for i=1:S
    for j=1:W
        if x(j+(i-1)*W)~=0
            X(j,(i-1)*T+ x(j+(i-1)*W))=1;
        end
    end
end

