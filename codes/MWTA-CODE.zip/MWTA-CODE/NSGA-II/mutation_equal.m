function child_3=mutation_equal(child_3,xnum,S)
index=randperm(xnum*S);
index1=index(1);
index2=index(2);
child_3([index1,index2])=child_3([index2,index1]);%��Ԫ�ػ���λ��


