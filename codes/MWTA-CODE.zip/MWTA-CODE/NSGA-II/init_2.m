function x = init_2(F,P,U,Time,nsga2para)%F(W,T*S)
pop=nsga2para.pop;
W = nsga2para.W;
T = nsga2para.T;
S = nsga2para.S;
mj = nsga2para.mj;
Ni=nsga2para.Ni;
objnum=nsga2para.objnum;
p = nsga2para.p;
v = nsga2para.v;
X = zeros(W,T*S,pop);%�����ƽ⼯
count = 1;
x=zeros(pop,W*S+objnum+2);%ʮ���ƽ⼯
while count <= pop
    sum_w = zeros(W,1);
    temp = zeros(W,T*S);
    for s = 1 : S
        for w = 1:W
            while 1 == 1
                temp_t = fix( rand(1) * (2*T-1) ) + 1; %����1��2T�������
                if( temp_t > T )
                    break;
                else
                    t = temp_t;
                    temp(w,t * s) = F(w,s * t);
                end;
                %����Ϸ���
                sum_t = sum(temp(:,t*s)); %�Ե�t�����
                sum_w(w,1) = sum_w(w,1) + temp(w,t*s);
                %��������������ѭ��,����temp(w,t)�ָ�Ϊ0�������
                if( ( sum_t <= mj( 1 , s * t) )  && ( sum_w(w,1) <= Ni(w,1) )  )
                    x(count,s*w) =  t;
                    break;
                else
                    sum_w(w,1) = sum_w(w,1) - temp(w,t*s);
                    temp(w,t*s) = 0;
                end
            end
        end
    end
    X(:,:,count) = temp;
    count = count + 1;
end
for i=1:pop
  x(i,W*S+1:W*S+objnum)=evaluate_objective(P,U,Time,x(i,:),nsga2para,v);
end

    
