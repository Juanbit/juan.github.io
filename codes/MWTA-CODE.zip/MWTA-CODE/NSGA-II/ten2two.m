function X=ten2two(x,nsga2para)
W=nsga2para.W;
T=nsga2para.T;
S=nsga2para.S;
objnum=nsga2para.objnum;
X=zeros(W,T*S);
for i=1:S
    for j=1:W
        if x(j+(i-1)*W)~=0
            X(j,(i-1)*T+ x(j+(i-1)*W))=1;
        end
    end
end

