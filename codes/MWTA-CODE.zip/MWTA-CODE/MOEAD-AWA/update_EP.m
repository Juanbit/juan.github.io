function EP=update_EP(ind,EP,mop,params)
a1=unique(EP,'rows');
EP=a1;
W=mop.W;
S=mop.S;
objnum=2;
%������
index=[];
temp=1;
for i=1:size(EP,1)
    if dominate_judge(ind.objective,EP(i,W*S+1:W*S+objnum)',mop)==-1%1��pf1֧��pf2��-1��pf2֧��pf1;0:����֧��
        temp=0;
        break
    elseif dominate_judge(ind.objective,EP(i,W*S+1:W*S+objnum)',mop)==1
        index=[index i];
        continue
    else
        continue
    end
end
EP(index,:)=[];%ɾ��EP�б�ind֧��Ľ�
EP1=EP(:,1:W*S+2*objnum);
EP=EP1;

if temp==1
    par=ind.parameter';%��ind����EP
    obj=ind.objective';
    norm_obj=ind.normal_objective';
    a=[par obj norm_obj];
    EP=[EP; a];
end

if size(EP,1)>params.popsize
   crowd_degree=calculate_crowd_degree(EP, mop);    
   [~, index]=sort(crowd_degree,'descend');
    EP=EP(index(1: params.popsize),1:W*S+2*objnum);
end

end
