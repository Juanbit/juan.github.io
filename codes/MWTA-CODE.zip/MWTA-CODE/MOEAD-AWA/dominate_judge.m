function index=dominate_judge(pf1, pf2, wta_parameter)
% minization problems
% return 1:  pf1 donimate pf2;
% return -1: pf2 donimate pf1;
% return 0:  pf1,pf2 is non donimate;
wta_parameter.objnum=2;
equal=sum(pf1==pf2);
 
if sum(pf1<pf2)==0 & equal~=wta_parameter.objnum
    index=-1;%pf2֧��pf1

elseif sum(pf1>pf2)==0 & equal~=wta_parameter.objnum
    index=1;%pf1֧��pf2

else index=0;
    
%     
% if pf1>=pf2 & equal~=wta_parameter.objnum
%     index=-1;
% elseif pf1<=pf2 & equal~=wta_parameter.objnum
%     index=1;
% else
%     index=0;
% end

end