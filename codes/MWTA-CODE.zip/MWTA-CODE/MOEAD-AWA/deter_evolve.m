function [subproblems, EP]  = deter_evolve(subproblems, mop, params, I, idealpoint, EP)
%function [subproblems evolve_nonsame_rate] = evolve(subproblems, mop, params, I,EP)
%global idealpoint
%evolve_parameter=[];
%count=0;
P=mop.P;
for i=1:length(I)
    %mop.deta=Ҳ�ǿ��Զ�̬���
    child_3=genetic_op_EP(EP, mop);
    %[child_3,P]= genetic_op1(subproblems, I(i), mop, params);
    %child_3=genetic_op_EP(EP, mop, params);
     %���Բ�����P���������update�� ��������Ⱥ�еĽ���и��£������񣿣�
     %ԭ�����Ƕ�P�е���������и���
     Child_3=ten2two(child_3,mop);
     Child_3_obj=deter_objective(mop.P,Child_3,mop);
     %�ù�һ���Ժ��Ŀ�꺯��ֵȥ�ۺϣ���ʱidealpoint=zeros(objDim,1)��֮��idealpointҲ�����ٸ���;
     
     old_obj=[subproblems.objective];
     %�����½�֮���ж��Ƿ���Ҫ���¹�һ�����н�
     if (max(max(Child_3_obj,[],2),max(old_obj,[],2))==max(old_obj,[],2)) & (min(min(Child_3_obj,[],2),min(old_obj,[],2))==min(old_obj,[],2))
         %��ʹ�������½⣬����Ⱥ�е�max��minû�б�
         Child_3_norm_obj=(Child_3_obj-min(old_obj,[],2))./(max(old_obj,[],2)-min(old_obj,[],2));
         if Child_3_norm_obj<subproblems(I(i)).normal_objective %���µ�ǰ������
             subproblems(I(i)).parameter=child_3;
             subproblems(I(i)).objective=Child_3_obj;
             subproblems(I(i)).norm_obj=Child_3_norm_obj;
             subproblems(I(i)).utility= subproblems(I(i)).utility;
         end
     else%��Ⱥ�е�max/min���ˣ���Ҫ���½������Ⱥ�����¹�һ��
         A=subproblems;%��ʱ�洢
         A(I(i)).objective=Child_3_obj;
         A_norm_obj=normalize([A.objective]);
         Child_3_norm_obj= A_norm_obj(:,I(i));
         if Child_3_norm_obj<subproblems(I(i)).normal_objective %���µ�ǰ������
             subproblems(I(i)).parameter=child_3;
             subproblems(I(i)).objective=Child_3_obj;
             %subproblems(I(i)).norm_obj=Child_3_norm_obj;
             cellpoints_norm_obj=num2cell(A_norm_obj, 1);
            [subproblems.normal_objective] = cellpoints_norm_obj{:};
            subproblems(I(i)).utility= subproblems(I(i)).utility;
         end
     end
     ind.parameter=child_3;
     ind.objective=Child_3_obj;
     ind.normal_objective=Child_3_norm_obj;      
     ind.utility=1;
     %update the EP
     EP=update_EP(ind,EP,mop,params);
     %update the neighbours.
     Nei=subproblems(I(i)).neighbour;
     
%      %%%%%%%%%%%%%%%%%%%%% old evolve%%%%%%%%%%%%%%%%%%%%%%%%
      subproblems(Nei)=update(subproblems(Nei),ind,idealpoint,params.nr,params);
      %count=1;
%      %%%%%%%%%%%%%%%%%%%%% old evolve%%%%%%%%%%%%%%%%%%%%%%%%

%  %%%%%%%%%%%%%%%%%%%%% new evolve0%%%%%%%%%%%%%%%%%%%%%%%%
%      max_EP_obj=max(EP(:,mop.W*mop.S+1:mop.W*mop.S+mop.objnum));
%      if sum(ind.objective'>max_EP_obj)>0
%          [ind_solu ind_obj]=re_init_indivi0(mop);
%          temp=[subproblems.objective];
%          temp(:,I(i))=ind_obj;
%          normal_temp=normalize(temp);
%          ind.parameter=ind_solu;
%          ind.objective=ind_obj;
%          ind.norm_obj=normal_temp(:,I(i));
%          ind.utility=1;
%          subproblems(Nei)=update(subproblems(Nei),ind,idealpoint,1,params);
%      else
%          subproblems(Nei)=update(subproblems(Nei),ind,idealpoint,mop.nr,params);%���µ�ǰ�����������
%      end
 %%%%%%%%%%%%%%%%%%%%% new evolve0%%%%%%%%%%%%%%%%%%%%%%%%

%      %%%%%%%%%%%%%%%%%%%%% new evolve1%%%%%%%%%%%%%%%%%%%%%%%%
%      max_EP_obj=max(EP(:,mop.W*mop.S+1:mop.W*mop.S+mop.objnum));
%      if ind.objective(1)>max_EP_obj(1)
%          x=re_init_indivi1(mop,params,max_EP_obj(1),2);
%          A=[subproblems.objective];
%          B=x(mop.W*mop.S+1:mop.W*mop.S+mop.objnum,:);
%          n1=size(B,2);
%          temp_obj=[A B];
%          temp_normal_obj=normalize(temp_obj);
%          
%          for k=1:n1
%                ind1.parameter=x(1:mop.W*mop.S,k);
%                ind1.objective=x(mop.W*mop.S+1:mop.W*mop.S+mop.objnum,k);
%                ind1.normal_objective=temp_normal_obj(:,end-k);
%               ind1.utility=1;
%               subproblems(Nei)=update(subproblems(Nei),ind1,idealpoint,1,params);
%          end
%      elseif ind.objective(2)>max_EP_obj(2)
%          
%          x=re_init_indivi2(mop,params,max_EP_obj(2),1);
%          A=[subproblems.objective];
%          B=x(mop.W*mop.S+1:mop.W*mop.S+mop.objnum,:);
%    
%          temp_obj=[A B];
%          temp_normal_obj=normalize(temp_obj);
%          
%          ind3.parameter=x(1:mop.W*mop.S,1);
%          ind3.objective=x(mop.W*mop.S+1:mop.W*mop.S+mop.objnum,1);
%          ind3.normal_objective=temp_normal_obj(:,end);
%          ind3.utility=1;
%          subproblems(Nei)=update(subproblems(Nei),ind3,idealpoint,1,params);
% %          n2=2
%      else
%          subproblems(Nei)=update(subproblems(Nei),ind,idealpoint,mop.nr,params);%���µ�ǰ�����������
%          count=count+1;
%         % n3=3
%      end   
%      %%%%%%%%%%%%%%%%%%%%% new evolve1%%%%%%%%%%%%%%%%%%%%%%%%
     
     %evolve_parameter=[evolve_parameter subproblems(i).parameter];
end
clear child_3 Child_3  Child_3_obj Child_3_norm_obj old_obj A A_norm_obj cellpoints_norm_obj ind Nei ind1 ind2 ind3
end

function subp=update(subp, ind,idealpoint, nr, params)
%�Խ�����genetic operation��Ľ�ind�����б�ѩ�򣨻��Ȩ��ͣ������Ŀ�꺯��ֵ
newobj=subobjective([subp.weight], ind.normal_objective, idealpoint, params.dmethod);
%��ind����������б�ѩ�򣨻��Ȩ��ͣ������Ŀ�꺯��ֵ
oldobj=subobjective([subp.weight], [subp.normal_objective],idealpoint, params.dmethod);
C = newobj < oldobj;
C_index=find(C==1);
C_size=length(C_index);
if C_size>nr 
    replace_num=nr;
else
    replace_num=C_size;
end
%n1=replace_num
temp1=randperm(C_size);
temp=temp1(1:replace_num);

% for i=1:replace_num
%     subp(C_index(temp(i))).parameter=ind.parameter;
%     subp(C_index(temp(i))).objective=ind.objective;
%     subp(C_index(temp(i))).normal_objective=ind.normal_objective;
% end    
CC=2>3;%��ʼȫΪfalse
CC(C_index(temp))=2<3;%����������ҵ���nr��λ����Ϊtrue
[subp(CC).parameter]=deal(ind.parameter);
[subp(CC).objective]=deal(ind.objective);
[subp(CC).normal_objective]=deal(ind.normal_objective);
[subp(CC).utility]=deal(ind.utility);
clear C CC newobj  oldobj temp1 temp;
end
%evolve_nonsame_rate=size(unique(evolve_parameter','rows'),1)/size(evolve_parameter',1);