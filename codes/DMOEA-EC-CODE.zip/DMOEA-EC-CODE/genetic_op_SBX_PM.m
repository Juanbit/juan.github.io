function ind = genetic_op_SBX_PM(subproblems, mop, index, params)
%the SBX crossover and the PM mutation
neighindex = subproblems(index).Neighbour;
neigh_solu = [subproblems(neighindex).Solution];
sub_solu = [subproblems.Solution];

if rand < params.deta
    pp = neigh_solu;
    Index = neighindex;
else
    pp = sub_solu;
    Index = [1:length(subproblems)];
end
%The random draw from the neighbours.
nsize = size(pp, 2);
s = ceil(rand * nsize);
while s == index
    s = ceil(rand * nsize);
end

parent1 = subproblems(index).Solution;
parent2 = pp(1:mop.solnum, s);  
%simulated binary crossover(SBX)
if rand < params.CR
    [child1, child2]=SBX(parent1, parent2, params.eta1);
else
    child1 = parent1;
    child2 = parent2;
end

if rand < 0.5
    child = child1;
else
    child = child2;
end

child = max(child, mop.domain(:,1));
child = min(child, mop.domain(:,2));
    
%polynomial mutation
for i = 1:length(child)
    if rand <= 1/mop.solnum  %params.MR
        child(i) = polynomial_mutation(child(i), mop.domain(i,2), mop.domain(i,1), params.eta2);
%         child2=polynomial_mutation(child2,mop.domain(:,2),mop.domain(:,1),params.eta2);
    else
        child(i) = child(i);
%         child2=child2;
    end
end

child = max(child, mop.domain(:,1));
child = min(child, mop.domain(:,2));     

if params.type == 1
     fobj = moead_testfun(mop.name);%moead test functions
elseif params.type == 2
    fobj = cec09(mop.name); %cec 09 competition
elseif params.type == 3
    fobj = SEMA_WFG(mop.name); %WFG1-9
end
newobj = fobj(child);
% newobj2=fobj(child2);
    
ind = struct('Solution', child, 'Objective', newobj, 'Constraint_Violation', []);
% ind2 = struct('Solution',child2,'Objective',newobj2,'Constraint_Violation',[]);

end