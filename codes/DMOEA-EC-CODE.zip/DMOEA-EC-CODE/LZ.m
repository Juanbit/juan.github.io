function fobj = LZ(name)
%LZ test problems
format long
switch name
        case 'LZ1'
            fobj = @LZ1;
        case 'LZ3'
            fobj = @LZ3;
        case 'LZ4'
            fobj = @LZ4; 
        case 'LZ7'
            fobj = @LZ7; 
        case 'LZ8'
            fobj = @LZ8;  
        case 'LZ9'
            fobj = @LZ9;
        otherwise
            fobj = @LZ1;
end
end

function f = LZ1(x)
pardim = 10;
% domain=[zeros(dim,1) ones(dim,1)];
f = zeros(2,1);
n = pardim;
J = [1:n]';
temp = (x-x(1).^(0.5 * (1 + 3 * (J - 2)./(n - 2)))).^2;
            
temp1 = temp(3: 2: end);
temp2 = temp(2: 2: end);
f(1) = x(1) + 2 * sum(temp1) /length(temp1);
f(2) = 1 - sqrt(x(1)) + 2 * sum(temp2) /length(temp2);
end

function f = LZ3(x)
pardim = 30;
% domain=[ 0 1;-1*ones(dim-1,1) ones(dim-1,1)]';
f = zeros(2,1);
n = pardim;
J = [1:n]';
temp = (x - 0.8 * x(1) * cos(6 * pi * x(1) + J * pi/n)).^2;
tempp = (x-0.8 * x(1) * sin(6 * pi * x(1)+J * pi/n)).^2;
            
temp1 = temp(3: 2: end);
temp2 = tempp(2: 2: end);
f(1) = x(1) + 2 * sum(temp1)/length(temp1);
f(2) = 1 - sqrt(x(1)) + 2 * sum(temp2)/length(temp2);
end

function f = LZ4(x)
pardim = 30;
% domain=[ 0 1;-1*ones(dim-1,1) ones(dim-1,1)]';
f = zeros(2,1);
n = pardim;
J = [1:n]';
temp = 6 * pi * x(1) + J*pi/n;
temp = (x - 0.8 * x(1) * cos(temp/3)).^2;
tempp = (x - 0.8 * x(1) * sin(temp)).^2;
            
temp1 = temp(3: 2: end);
temp2 = tempp(2: 2: end);
f(1) = x(1) + 2 * sum(temp1)/length(temp1);
f(2) = 1 - sqrt(x(1)) + 2 * sum(temp2)/length(temp2);
end

function f = LZ7(x)
pardim = 10;
% domain=[ zeros(dim,1) ones(dim,1)]';
f = zeros(2,1);
n = pardim;
            
J = [1:n]';
yy = x - x(1).^(0.5*(1 + 3 * (J - 2)./(n - 2)));                    
temp = 4* yy.^2 - cos(8* yy *pi) + 1;
            
temp1 = temp(3: 2: end);
temp2 = temp(2: 2: end);
f(1) = x(1) + 2 * sum(temp1)/length(temp1);
f(2) = 1 - sqrt(x(1)) + 2 * sum(temp2)/length(temp2);
end

function f = LZ8(x)
pardim = 10;
% domain=[ zeros(dim,1) ones(dim,1)]';
 f = zeros(2,1);
n = pardim;
            
J = [1:n]';
yy = x - x(1).^(0.5 * (1 + 3 * (J - 2)./(n - 2)));                    
temp1 = yy.^2;
temp2 = cos(20 * yy * pi./sqrt(J));
            
temp3 = temp1(3: 2: end);
temp4 = temp2(3: 2: end);
            
temp5 = temp1(2: 2: end);
temp6 = temp2(2: 2: end);
            
f(1) = x(1) + 2 * (4 * sum(temp3) - 2 * prod(temp4) + 2)/length(temp3);
f(2) = 1 - sqrt(x(1)) + 2 * (4 * sum(temp5) - 2 * prod(temp6) + 2)/length(temp5);
end

function f = LZ9(x)
pardim = 30;
% domain=[ 0 1;-1*ones(dim-1,1) ones(dim-1,1)]';
f = zeros(2,1);
n = pardim;
            
J = [1:n]';
temp = (x - sin(6 * pi * x(1) + J * pi/n)).^2;
            
temp1 = temp(3: 2: end);
temp2 = temp(2: 2: end);    
            
f(1) = x(1) + 2 * sum(temp1)/length(temp1);
f(2) = 1 - x(1)^2 + 2 * sum(temp2)/length(temp2);
end

