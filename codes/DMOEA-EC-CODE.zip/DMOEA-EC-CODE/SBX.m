function [child1, child2] = SBX(parent1, parent2, eta)
%simulated binary crossover(SBX)
u = rand;
if u<= 0.5
    beta_q = (2 * u)^(1/(eta + 1));
else
    beta_q = (1/2 * (1 - u))^(1/(eta + 1));
end
child1 = 0.5.*((1 + beta_q).*parent1 + (1 - beta_q).*parent2);
child2 = 0.5.*((1 - beta_q).*parent1 + (1 + beta_q).*parent2);
end