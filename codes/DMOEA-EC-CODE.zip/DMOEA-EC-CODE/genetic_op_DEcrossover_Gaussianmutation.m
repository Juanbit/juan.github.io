function ind = genetic_op_DEcrossover_Gaussianmutation(subproblems, mop, index, params)
%the DE crossover and the Gaussian mutation (used for the ZDT DTLZ WFG test instances)
%GENETICOP function implemented the DE operation to generate a new
%individual from a subproblems and its neighbours.

%   subproblems: is all the subproblems.
%   index: the index of the subproblem need to handle.
%   domain: the domain of the origional multiobjective problem.
%   ind: is an individual structure.
neighindex = subproblems(index).Neighbour;
neigh_solu = [subproblems(neighindex).Solution];
sub_solu = [subproblems.Solution];

if rand < params.deta
    pp = neigh_solu;
    Index = neighindex;
else
    pp = sub_solu;
    Index = [1 :length(subproblems)];
end
nsize = length(Index);


si = ones(1,3) * index;
si(1) = Index(ceil(rand * nsize));
while si(1) == index
        si(1) = Index(ceil(rand * nsize));
end
si(2) = Index(ceil(rand * nsize));
while si(2) == index || si(2) == si(1)
    si(2) = Index(ceil(rand * nsize));
end
si(3) = Index(ceil(rand * nsize));
while si(3) == index || si(3) == si(2) || si(3) == si(1)
    si(3) = Index(ceil(rand * nsize));
end

selectsolus = [subproblems(si).Solution];
% selectsolus = pp(:,si);

oldsolu = subproblems(index).Solution;
%DE crossover
jrandom = ceil(rand * mop.solnum);
randomarray = rand(mop.solnum, 1);
deselect = randomarray < params.CR;
deselect(jrandom) = true;
newsolu = selectsolus(:,1) + params.F * (selectsolus(:,2) - selectsolus(:,3));
newsolu(~deselect) = oldsolu(~deselect);
    
newsolu = max(newsolu, mop.domain(:,1));
newsolu = min(newsolu, mop.domain(:,2));

%Gaussian mutation
newsolu = gaussian_mutate(newsolu, 1/mop.solnum, mop.domain);

if params.type == 1
    fobj = moead_testfun(mop.name);%moead test functions
elseif params.type == 2
    fobj = cec09(mop.name); %cec 09 competition
elseif params.type == 3
    fobj = SEMA_WFG(mop.name);%WFG1-9
elseif params.type == 6
    fobj = LZ(mop.name); %LZ
end
newobj = fobj(newsolu);
ind = struct('Solution', newsolu, 'Objective', newobj, 'Constraint_Violation', []);

end