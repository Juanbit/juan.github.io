function ind = randompoint(mop, popsize, type)
%randomly initialize solutions

randarray  =  rand(mop.solnum, popsize);
lowend  =  mop.domain(:, 1);
span  =  mop.domain(:, 2) - lowend;
solu  =  randarray.*(span(:,ones(1, popsize))) + lowend(:, ones(1,popsize));

ind = struct('Solution', [], 'Objective', []);

if type == 1
    fobj = moead_testfun(mop.name); %moead test functions
elseif type == 2
    fobj  =  cec09(mop.name); %cec 09 competition
elseif type == 3
    fobj  =  SEMA_WFG(mop.name); %WFG1-9
elseif type == 6  %LZ
    fobj  =  LZ(mop.name);
end
for i = 1:popsize
    ind(i).Solution = solu(:, i);
    ind(i).Objective = fobj(solu(:, i));
end
end