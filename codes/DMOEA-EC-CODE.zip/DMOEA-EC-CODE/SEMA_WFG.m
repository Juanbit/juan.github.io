function fobj=SEMA_WFG(name)
format long
switch name
        case 'WFG21'
            fobj = @WFG21;
        case 'WFG31'
            fobj = @WFG31;
        case 'WFG22'
            fobj = @WFG22; 
        case 'WFG32'
            fobj = @WFG32; 
        case 'WFG23'
            fobj = @WFG23;  
        case 'WFG33'
            fobj = @WFG33;
        case 'WFG24'
            fobj = @WFG24;
        case 'WFG34'
            fobj = @WFG34;
        case 'WFG25'
            fobj = @WFG25;
        case 'WFG35'
            fobj = @WFG35;
        case 'WFG26'
            fobj = @WFG26;
        case 'WFG36'
            fobj = @WFG36;
        case 'WFG27'
            fobj = @WFG27; 
        case 'WFG37'
            fobj = @WFG37;
        case 'WFG28'
            fobj = @WFG28; 
        case 'WFG38'
            fobj = @WFG38;
        case 'WFG29'
            fobj = @WFG29;
        case 'WFG39'
            fobj = @WFG39;
        otherwise
            fobj = @WFG21;
end
end

function f = WFG21(z)
dim=30;k=2;l=28;odim=2;pd=dim;%pd=k+1;
domain=[zeros(pd,1) 2.*(1:pd)']';
% z=z';
z01=z./domain(2,:)'; y=z01;
t1 = zeros(pd,1);t2 = zeros(pd,1);t3 = zeros(pd,1);t4 = zeros(odim,1); 
t1(1:k) = y(1:k);
for i =(k+1):pd
    t1(i) = s_linear(y(i),0.35);
end
t2(1:k) = t1(1:k);
for i =(k+1):pd
    t2(i) = b_flat(t1(i),0.8,0.75,0.85);
end
for i =1:pd
    t3(i) = b_poly(t2(i),0.02);
end
for i =1:(odim-1)
    t4(i) = r_sum(t3((i-1)*k/(odim-1)+(1:(odim-1))'),2*(i-1)*k/(odim-1)+2*(1:(odim-1))');
end
t4(odim) = r_sum(t3((k+1):pd),2*((k+1):pd)');
x = zeros(odim,1);
for i = 1:(odim-1)
    x(i) = max(t4(odim),1)*(t4(i)-0.5) + 0.5;
end
x(odim) = t4(odim);
S=2.*(1:odim)';
D=1;
hm=shape('convex',x,odim);
hm(odim)=mixedM(x,1,5);           
f=D*x(odim)+S.*hm;
% f=f';
end

function f = WFG31(z)
dim=30;k=2;l=28;odim=3;pd=dim;%pd=k+1;
domain=[zeros(pd,1) 2.*(1:pd)']';
% z=z';
z01=z./domain(2,:)'; y=z01;
t1 = zeros(pd,1);t2 = zeros(pd,1);t3 = zeros(pd,1);t4 = zeros(odim,1); 
t1(1:k) = y(1:k);
for i =(k+1):pd
    t1(i) = s_linear(y(i),0.35);
end
t2(1:k) = t1(1:k);
for i =(k+1):pd
    t2(i) = b_flat(t1(i),0.8,0.75,0.85);
end
for i =1:pd
    t3(i) = b_poly(t2(i),0.02);
end
for i =1:(odim-1)
    t4(i) = r_sum(t3((i-1)*k/(odim-1)+(1:(odim-1))'),2*(i-1)*k/(odim-1)+2*(1:(odim-1))');
end
t4(odim) = r_sum(t3((k+1):pd),2*((k+1):pd)');
x = zeros(odim,1);
for i = 1:(odim-1)
    x(i) = max(t4(odim),1)*(t4(i)-0.5) + 0.5;
end
x(odim) = t4(odim);
S=2.*(1:odim)';
D=1;
hm=shape('convex',x,odim);
hm(odim)=mixedM(x,1,5);           
f=D*x(odim)+S.*hm;
% f=f';
end

function f = WFG22(z)
dim=30;k=2;l=28;odim=2;pd=dim;%pd=k+1;
domain=[zeros(pd,1) 2.*(1:pd)']';
% z=z';
z01=z./domain(2,:)'; y=z01;
t1 = zeros(pd,1);t2 = zeros(pd,1);t3 = zeros(odim,1);
t1(1:k) = y(1:k);
for i =(k+1):pd
    t1(i) = s_linear(y(i),0.35);
end
t2(1:k) = t1(1:k);l = pd - k;
for i = (k+1):(k+(l/2))
    t2(i) = r_nonsep([t1(k+2*(i-k)-1);t1(k+2*(i-k))],2);
end
for i =1:(odim-1)
    t3(i) = r_sum(t2((i-1)*k/(odim-1) +(1:(odim-1))), ones(odim-1,1));
end
t3(odim) = r_sum(t2(k+(1:(l/2))), ones(l/2,1));
x = zeros(odim,1);
for i = 1:(odim-1)
    x(i) = max(t3(odim),1)*(t3(i)-0.5) + 0.5;
end
x(odim) = t3(odim);
S=2.*(1:odim)';
D=1;
hm=shape('convex',x,odim);
hm(end)=discM(x,1,1,5);           
f=D*x(odim)+S.*hm;
% f=f';
end

function f = WFG32(z)
dim=30;k=2;l=28;odim=3;pd=dim;%pd=k+1;
domain=[zeros(pd,1) 2.*(1:pd)']';
% z=z';
z01=z./domain(2,:)'; y=z01;
t1 = zeros(pd,1);t2 = zeros(pd,1);t3 = zeros(odim,1);
t1(1:k) = y(1:k);
for i =(k+1):pd
    t1(i) = s_linear(y(i),0.35);
end
t2(1:k) = t1(1:k);l = pd - k;
for i = (k+1):(k+(l/2))
    t2(i) = r_nonsep([t1(k+2*(i-k)-1);t1(k+2*(i-k))],2);
end
for i =1:(odim-1)
    t3(i) = r_sum(t2((i-1)*k/(odim-1) +(1:(odim-1))), ones(odim-1,1));
end
t3(odim) = r_sum(t2(k+(1:(l/2))), ones(l/2,1));
x = zeros(odim,1);
for i = 1:(odim-1)
    x(i) = max(t3(odim),1)*(t3(i)-0.5) + 0.5;
end
x(odim) = t3(odim);
S=2.*(1:odim)';
D=1;
hm=shape('convex',x,odim);
hm(end)=discM(x,1,1,5);           
f=D*x(odim)+S.*hm;
% f=f';
end

function f = WFG23(z)
dim=30;k=2;l=28;odim=2;pd=dim;%pd=k+1;
domain=[zeros(pd,1) 2.*(1:pd)']';
% z=z';
z01=z./domain(2,:)'; y=z01;
t1 = zeros(pd,1);t2 = zeros(pd,1);t3 = zeros(odim,1); 
t1(1:k) = y(1:k);
for i =(k+1):pd
    t1(i) = s_linear(y(i),0.35);
end
t2(1:k) = t1(1:k); l = pd - k;
for i = (k+1):(k+(l/2))
    t2(i) = r_nonsep([t1(k+2*(i-k)-1);t1(k+2*(i-k))],2);
end
for i =1:(odim-1)
    t3(i) = r_sum(t2((i-1)*k/(odim-1) +(1:(odim-1))), ones(odim-1,1));
end
t3(odim) = r_sum(t2(k+(1:(l/2))), ones(l/2,1));
x = zeros(odim,1);
for i = 1:(odim-1)
    if i ==1; ii=1; else ii=0;end
    x(i) = max(t3(odim),ii)*(t3(i)-0.5) + 0.5;
end
x(odim) = t3(odim);
S=2.*(1:odim)';
D=1;
hm=shape('linear',x,odim);          
f=D*x(odim)+S.*hm;
% f=f';
end

function f = WFG33(z)
dim=30;k=2;l=28;odim=3;pd=dim;%pd=k+1;
domain=[zeros(pd,1) 2.*(1:pd)']';
% z=z';
z01=z./domain(2,:)'; y=z01;
t1 = zeros(pd,1);t2 = zeros(pd,1);t3 = zeros(odim,1); 
t1(1:k) = y(1:k);
for i =(k+1):p.pd
    t1(i) = s_linear(y(i),0.35);
end
t2(1:k) = t1(1:k); l = pd - k;
for i = (k+1):(k+(l/2))
    t2(i) = r_nonsep([t1(k+2*(i-k)-1);t1(k+2*(i-k))],2);
end
for i =1:(odim-1)
    t3(i) = r_sum(t2((i-1)*k/(odim-1) +(1:(odim-1))), ones(odim-1,1));
end
t3(odim) = r_sum(t2(k+(1:(l/2))), ones(l/2,1));
x = zeros(odim,1);
for i = 1:(odim-1)
    if i ==1; ii=1; else ii=0;end
    x(i) = max(t3(odim),ii)*(t3(i)-0.5) + 0.5;
end
x(odim) = t3(odim);
S=2.*(1:odim)';
D=1;
hm=shape('linear',x,odim);          
f=D*x(odim)+S.*hm;
% f=f';
end

function f = WFG24(z)
dim=30;k=2;l=28;odim=2;pd=dim;%pd=k+1;
domain=[zeros(pd,1) 2.*(1:pd)']';
% z=z';
z01=z./domain(2,:)'; y=z01;
t1 = zeros(pd,1);t2 = zeros(odim,1);
for i =1:pd
    t1(i) = s_multi(y(i),30,10,0.35);
end
for i =1:(odim-1)
    t2(i) = r_sum(t1((i-1)*k/(odim-1) + (1:(odim-1))),ones(odim-1,1));
end
t2(odim) = r_sum(t1((k+1):pd),ones(pd-k,1));
x = zeros(odim,1);
for i = 1:(odim-1)
    x(i) = max(t2(odim),1)*(t2(i)-0.5) + 0.5;
end
x(odim) = t2(odim);
S=2.*(1:odim)';
D=1;
hm=shape('concave',x,odim);          
f=D*x(odim)+S.*hm;
% f=f';
end

function f = WFG34(z)
dim=30;k=2;l=28;odim=3;pd=dim;%pd=k+1;
domain=[zeros(pd,1) 2.*(1:pd)']';
% z=z';
z01=z./domain(2,:)'; y=z01;
t1 = zeros(pd,1);t2 = zeros(odim,1);
for i =1:pd
    t1(i) = s_multi(y(i),30,10,0.35);
end
for i =1:(odim-1)
    t2(i) = r_sum(t1((i-1)*k/(odim-1) + (1:(odim-1))),ones(odim-1,1));
end
t2(odim) = r_sum(t1((k+1):pd),ones(pd-k,1));
x = zeros(odim,1);
for i = 1:(odim-1)
    x(i) = max(t2(odim),1)*(t2(i)-0.5) + 0.5;
end
x(odim) = t2(odim);
S=2.*(1:odim)';
D=1;
hm=shape('concave',x,odim);          
f=D*x(odim)+S.*hm;
% f=f';
end

function f = WFG25(z)
dim=30;k=2;l=28;odim=2;pd=dim;%pd=k+1;
domain=[zeros(pd,1) 2.*(1:pd)']';
% z=z';
z01=z./domain(2,:)'; y=z01;
for i =1:pd
    t1(i) = s_decept(y(i),0.35,0.001,0.05);
end
t2 = zeros(odim,1);
for i =1:(odim-1)
    t2(i) = r_sum(t1((i-1)*k/(odim-1)+(1:(odim-1))'),ones(odim-1,1));
end
t2(odim) = r_sum(t1((k+1):pd),ones(pd-k,1)); 
x = zeros(odim,1);
for i = 1:(odim-1)
    x(i) = max(t2(odim),1)*(t2(i)-0.5) + 0.5;
end
x(odim) = t2(odim);                        
S=2.*(1:odim)';
D=1;
hm=shape('concave',x,odim);          
f=D*x(odim)+S.*hm;
% f=f';
end

function f = WFG35(z)
dim=30;k=2;l=28;odim=3;pd=dim;%pd=k+1;
domain=[zeros(pd,1) 2.*(1:pd)']';
% z=z';
z01=z./domain(2,:)'; y=z01;
for i =1:pd
    t1(i) = s_decept(y(i),0.35,0.001,0.05);
end
t2 = zeros(odim,1);
for i =1:(odim-1)
    t2(i) = r_sum(t1((i-1)*k/(odim-1)+(1:(odim-1))'),ones(odim-1,1));
end
t2(odim) = r_sum(t1((k+1):pd),ones(pd-k,1)); 
x = zeros(odim,1);
for i = 1:(odim-1)
    x(i) = max(t2(odim),1)*(t2(i)-0.5) + 0.5;
end
x(odim) = t2(odim);                        
S=2.*(1:odim)';
D=1;
hm=shape('concave',x,odim);          
f=D*x(odim)+S.*hm;
% f=f';
end

function f = WFG26(z)
dim=30;k=2;l=28;odim=2;pd=dim;%pd=k+1;
domain=[zeros(pd,1) 2.*(1:pd)']';
% z=z';
z01=z./domain(2,:)'; y=z01;
t1 = zeros(pd,1);t2 = zeros(odim,1); 

t1(1:k) = y(1:k);
for i =(k+1):pd
    t1(i) = s_linear(y(i),0.35);
end  

for i=1:(odim-1)
%     t2(i) = r_nonsep(t1((i-1)*k/(odim-1) + (1:(odim-1))),k/(odim-1));
    t2(i) = r_nonsep(t1((i-1)*k/(odim-1)+1:i*k/(odim-1)),k/(odim-1));
end
t2(odim) = r_nonsep(t1((k+1):pd),pd-k);

x = zeros(odim,1);
for i = 1:(odim-1)
    x(i) = max(t2(odim),1)*(t2(i)-0.5) + 0.5;
end
x(odim) = t2(odim);  

S=2.*(1:odim)';
D=1;

% hm=shape('concave',x,odim);           
% f=D*x(odim)+S.*hm;

hm1=shape1('concave',x,1);
f1=D*x(odim)+S(1)*hm1;
hm2=shape1('concave',x,2);  
f2=D*x(odim)+S(2)*hm2;
f=[f1; f2];
% f=f';
end

function f = WFG36(z)
dim=30;k=2;l=28;odim=3;pd=dim;%pd=k+1;
domain=[zeros(pd,1) 2.*(1:pd)']';
% z=z';
z01=z./domain(2,:)'; y=z01;
t1 = zeros(pd,1);t2 = zeros(odim,1); 
t1(1:k) = y(1:k);
for i =(k+1):pd
    t1(i) = s_linear(y(i),0.35);
end  
for i=1:(odim-1)
    t2(i) = r_nonsep(t1((i-1)*k/(odim-1) + (1:(odim-1))),k/(odim-1));
end
t2(odim) = r_nonsep(t1((k+1):pd),pd-k);
x = zeros(odim,1);
for i = 1:(odim-1)
    x(i) = max(t2(odim),1)*(t2(i)-0.5) + 0.5;
end
x(odim) = t2(odim);                       
S=2.*(1:odim)';
D=1;
hm=shape('concave',x,odim);          
f=D*x(odim)+S.*hm;
% f=f';
end

function f = WFG27(z)
dim=30;k=2;l=28;odim=2;pd=dim;%pd=k+1;
domain=[zeros(pd,1) 2.*(1:pd)']';
% z=z';
z01=z./domain(2,:)'; y=z01;
t1 = zeros(pd,1);t2 = zeros(pd,1); t3 = zeros(odim,1); 
for i =1:k
    t1(i) = b_param(y(i),r_sum(y((i+1):pd),ones(pd-i,1)),0.98/49.98,0.02,50);
end
t1((k+1):pd) = y((k+1):pd);
t2(1:k) = t1(1:k);
for i =(k+1):pd
    t2(i) = s_linear(t1(i),0.35);
end            
for i =1:(odim-1)
    t3(i) = r_sum(t2((i-1)*k/(odim-1) + (1:(odim-1))),ones(odim-1,1));
end
t3(odim) = r_sum(t2((k+1):pd),ones(pd-k,1));            
x = zeros(odim,1);
for i = 1:(odim-1)
    x(i) = max(t3(odim),1)*(t3(i)-0.5) + 0.5;
 end
x(odim) = t3(odim);                       
S=2.*(1:odim)';
D=1;
hm=shape('concave',x,odim);          
f=D*x(odim)+S.*hm;
% f=f';
end

function f = WFG37(z)
dim=30;k=2;l=28;odim=3;pd=dim;%pd=k+1;
domain=[zeros(pd,1) 2.*(1:pd)']';
% z=z';
z01=z./domain(2,:)'; y=z01;
t1 = zeros(pd,1);t2 = zeros(pd,1); t3 = zeros(odim,1); 
for i =1:k
    t1(i) = b_param(y(i),r_sum(y((i+1):pd),ones(pd-i,1)),0.98/49.98,0.02,50);
end
t1((k+1):pd) = y((k+1):pd);
t2(1:k) = t1(1:k);
for i =(k+1):pd
    t2(i) = s_linear(t1(i),0.35);
end            
for i =1:(odim-1)
    t3(i) = r_sum(t2((i-1)*k/(odim-1) + (1:(odim-1))),ones(odim-1,1));
end
t3(odim) = r_sum(t2((k+1):pd),ones(pd-k,1));            
x = zeros(odim,1);
for i = 1:(odim-1)
    x(i) = max(t3(odim),1)*(t3(i)-0.5) + 0.5;
 end
x(odim) = t3(odim);                       
S=2.*(1:odim)';
D=1;
hm=shape('concave',x,odim);          
f=D*x(odim)+S.*hm;
% f=f';
end

function f = WFG28(z)
dim=30;k=2;l=28;odim=2;pd=dim;%pd=k+1;
domain=[zeros(pd,1) 2.*(1:pd)']';
% z=z';
z01=z./domain(2,:)'; y=z01;
t1 = zeros(pd,1);t2 = zeros(pd,1); t3 = zeros(odim,1); 
t1(1:k) = y(1:k);
for i =(k+1):pd
    t1(i) = b_param(y(i),r_sum(y(1:(i-1)),ones(i-1,1)),0.98/49.98,0.02,50);
end
t2(1:k) = t1(1:k);
for i =(k+1):pd
    t2(i) = s_linear(t1(i),0.35);
end            
for i =1:(odim-1)
    t3(i) = r_sum(t2((i-1)*k/(odim-1) + (1:(odim-1))),ones(odim-1,1));
end
t3(odim) = r_sum(t2((k+1):pd),ones(pd-k,1));            
x = zeros(odim,1);
for i = 1:(odim-1)
    x(i) = max(t3(odim),1)*(t3(i)-0.5) + 0.5;
end
x(odim) = t3(odim);                       
S=2.*(1:odim)';
D=1;
hm=shape('concave',x,odim);          
f=D*x(odim)+S.*hm;
% f=f';
end

function f = WFG38(z)
dim=30;k=2;l=28;odim=3;pd=dim;%pd=k+1;
domain=[zeros(pd,1) 2.*(1:pd)']';
% z=z';
z01=z./domain(2,:)'; y=z01;
t1 = zeros(pd,1);t2 = zeros(pd,1); t3 = zeros(odim,1); 
t1(1:k) = y(1:k);
for i =(k+1):pd
    t1(i) = b_param(y(i),r_sum(y(1:(i-1)),ones(i-1,1)),0.98/49.98,0.02,50);
end
t2(1:k) = t1(1:k);
for i =(k+1):pd
    t2(i) = s_linear(t1(i),0.35);
end            
for i =1:(odim-1)
    t3(i) = r_sum(t2((i-1)*k/(odim-1) + (1:(odim-1))),ones(odim-1,1));
end
t3(odim) = r_sum(t2((k+1):pd),ones(pd-k,1));            
x = zeros(odim,1);
for i = 1:(odim-1)
    x(i) = max(t3(odim),1)*(t3(i)-0.5) + 0.5;
end
x(odim) = t3(odim);                       
S=2.*(1:odim)';
D=1;
hm=shape('concave',x,odim);          
f=D*x(odim)+S.*hm;
% f=f';
end

function f = WFG29(z)
dim=30;k=2;l=28;odim=2;pd=dim;%pd=k+1;
domain=[zeros(pd,1) 2.*(1:pd)']';
z01=z./domain(2,:)'; 
y=z01;
t1 = zeros(pd,1);t2 = zeros(pd,1); t3 = zeros(odim,1); 
for i =1:(pd-1)
    t1(i) = b_param(y(i),r_sum(y((i+1):pd),ones(pd-i,1)),0.98/49.98,0.02,50);%ones
end
t1(pd) = y(pd);

for i=1:k
    t2(i) = s_decept(t1(i),0.35,0.001,0.05);
end
for i=(k+1):pd
    t2(i) = s_multi(t1(i),30,95,0.35);%ok
end
% t2

for i=1:(odim-1)
%     t3(i) = r_nonsep(t2((i-1)*k/(odim-1) + (1:(odim-1))),k/(odim-1));
    t3(i) = r_nonsep(t2((i-1)*k/(odim-1)+1:i*k/(odim-1)),k/(odim-1));
end
t3(odim) = r_nonsep(t2((k+1):pd),pd-k);

x = zeros(odim,1);
for i = 1:(odim-1)
    x(i) = max(t3(odim),1)*(t3(i)-0.5) + 0.5;
end
x(odim) = t3(odim);

S=2.*(1:odim)';
D=1;

% hm=shape('concave',x,odim);    
% % hm
% f=D*x(odim)+S.*hm;

hm1=shape1('concave',x,1);
f1=D*x(odim)+S(1)*hm1;
hm2=shape1('concave',x,2);  
f2=D*x(odim)+S(2)*hm2;
f=[f1; f2];
% f=f';
end

function f = WFG39(z)
dim=30;k=2;l=28;odim=3;pd=dim;%pd=k+1;
domain=[zeros(pd,1) 2.*(1:pd)']';
% z=z';
z01=z./domain(2,:)'; y=z01;
t1 = zeros(pd,1);t2 = zeros(pd,1); t3 = zeros(odim,1); 
for i =1:(pd-1)
    t1(i) = b_param(y(i),r_sum(y((i+1):pd),ones(pd-i,1)),0.98/49.98,0.02,50);
end
t1(pd) = y(pd);
for i=1:k
    t2(i) = s_decept(t1(i),0.35,0.001,0.05);
end
for i=(k+1):pd
    t2(i) = s_multi(t1(i),30,95,0.35);
end
for i=1:(odim-1)
    t3(i) = r_nonsep(t2((i-1)*k/(odim-1) + (1:(odim-1))),k/(odim-1));
end
t3(odim) = r_nonsep(t2((k+1):pd),pd-k);
x = zeros(odim,1);
for i = 1:(odim-1)
    x(i) = max(t3(odim),1)*(t3(i)-0.5) + 0.5;
end
x(odim) = t3(odim);                       
S=2.*(1:odim)';
D=1;
hm=shape('concave',x,odim);          
f=D*x(odim)+S.*hm;
% f=f';
end

 function hm=shape(name,x,M)
%         M=p.od;
        hm=zeros(M,1);
        switch name
            case 'linear'
                hm(1)=prod(x(1:(M-1)));
                for m=2:(M-1)
                    hm(m)=prod(x(1:(M-m)))*(1-x(M-m+1));
                end
                hm(M)=1-x(1);
            case 'convex'
                hm(1)=prod(1-cos(pi*x(1:(M-1))./2));
                for m=2:(M-1)
                    hm(m)=prod(1-cos(pi*x(1:(M-m))./2)).*(1-sin(pi*x(M-m+1)/2));
                end
                hm(M)=1-sin(pi*x(1)/2);
            case 'concave'
                 hm(1)=prod((sin(pi*x(1:(M-1))./2)));
                for m=2:(M-1)
                    hm(m)=prod((sin(pi*x(1:(M-m))./2)))*(cos(pi*x(M-m+1)/2));
                end
                hm(M)=cos(pi*x(1)/2);                               
        end                
 end
    
 function hm=shape1(name,x,m)
        M=length(x);
%         hm=zeros(M,1);
        switch name
            case 'linear'
%                 hm=zeros(M,1);
%                 hm(1)=prod(x(1:(M-1)));
%                 for m=2:(M-1)
%                     hm(m)=prod(x(1:(M-m)))*(1-x(M-m+1));
%                 end
%                 hm(M)=1-x(1);

                hm=1;
                for i=1:M-m
                    hm=hm*x(i);
                end
                if m~=1
                    hm=hm*(1-x(M-m+1));
                end                

            case 'convex'
                hm=zeros(M,1);
                hm(1)=prod(1-cos(pi*x(1:(M-1))./2));
                for m=2:(M-1)
                    hm(m)=prod(1-cos(pi*x(1:(M-m))./2)).*(1-sin(pi*x(M-m+1)/2));
                end
                hm(M)=1-sin(pi*x(1)/2);
            case 'concave'
                hm=1;
                for i=1:M-m
                   temp1=sin(x(i)*pi*0.5);
                   hm=hm*temp1;
                end
                if m~=1
                   temp2=cos(x(M-m+1)*pi*0.5);
                   hm=hm*temp2;
                end                            
        end                
    end
    function sp=mixedM(x,a,A)
        sp=(1-x(1)-(cos(2*A*pi*x(1)+pi/2))/(2*A*pi))^a;
    end
    function sp=discM(x,a,b,A)
        sp=1-(x(1)^a)*(cos(A*(x(1)^b)*pi))^2;
    end
    function t=b_poly(y,a)
        t=y.^a;
    end
    function t=b_flat(y,A,B,C)
        t=A+min(0,floor(y-B)).*((A.*(B-y))./B)-min(0,floor(C-y)).*(((1-A).*(y-C))./(1-C));
    end
    function t=b_param(y,y1,A,B,C)
        t = y^(B + (C-B) * v(y1));
        function vv=v(x)
            vv = A - (1-2*x)*abs(floor(0.5-x)+A);
        end 
    t=correct_to_01(t);
    end
    function t=s_linear(y,A)
        t = abs(y-A)./(abs(floor(A-y)+A));
    end
    function t=s_decept(y,A,B,C)
        t = 1+(abs(y-A)-B).*((floor(y-A+B).*(1-C+(A-B)/B))./(A-B)+(floor(A+B-y).*(1-C+(1-A-B)/B))./(1-A-B)+1/B);
    end
    function t=s_multi(y,A,B,C)
        t = (1 + cos((4*A+2)*pi*(0.5-(abs(y-C))/(2*(floor(C-y)+C)))) +4*B*((abs(y-C))/(2*(floor(C-y)+C)))^2)/(B+2);
    end
    function t=r_sum(y,w)
        t=dot(y,w)/sum(w);
    end
    function t=r_nonsep(y,A)
        ny = length(y);
       denominator=(ny/A)*ceil(A/2)*(1+2*A-2*ceil(A/2));
        numerator = 0;
        for j =0:ny-1
            numerator=numerator+y(j+1);
            for k=0:A-2
                temp=mod(j+k+1,ny);
                numerator=numerator+abs(y(j+1)-y(temp+1));
%                 tt=y(j+1)-y(temp+1)
            end
%             tp1 = tp1 + (y(j) + sum(abs(y(j) - y(mod(1+j + (0:(A-2)),ny)+1))));
        end
        t = numerator/denominator;
        t=correct_to_01(t);
    end
    
    function t=correct_to_01(t)
    min=0;
    max=1;
    epsilon = 1.0e-10;
    min_epsilon = min - epsilon;
    max_epsilon = max + epsilon;
    if (t<=min && t>=min_epsilon) || (t >= min && t <= min_epsilon);
        t=min;
    elseif (t>=max && t<=max_epsilon) || (t <= max && t >= max_epsilon);
        t=max;
    else
        t=t;
    end
    end