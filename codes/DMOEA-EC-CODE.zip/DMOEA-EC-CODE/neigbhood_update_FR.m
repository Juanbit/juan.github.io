function [subp, flag] = neigbhood_update_FR(subp, ind, neigh,  params, mop)
%Using the feasibility rule to upate neighboring solutions

main_obj_index = mop.main_obj_index;
constraint_index = mop.constraint_index;

global idealpoint nadirpoint
ind_temp = (ind.Objective - idealpoint)./(nadirpoint - idealpoint);
nr_count = 0;
flag = false;

for i = 1 : length(neigh) 
    ind_CV = ind_temp(constraint_index) - subp(neigh(i)).Epsilon; 
    ind_CV1 = ind_CV;
    ind_CV1(ind_CV1 < 0) = 0;
    ind_f = ind.Objective(main_obj_index) + 10^(-6) * sum(ind.Objective(constraint_index));
      
    subp_i_CV = subp(neigh(i)).Constraint_Violation;
    subp_i_CV1 = subp_i_CV;
    subp_i_CV1(subp_i_CV1 < 0) = 0;
    subp_i_f = subp(neigh(i)).Objective(main_obj_index) + 10^(-6) * sum(subp(neigh(i)).Objective(constraint_index));
    
    if sum(ind_CV1) == sum(subp_i_CV1) %sum(ind_CV1)==0 & sum(subp_i_CV1)==0
        if ind_f < subp_i_f
            subp(neigh(i)).Solution = ind.Solution;
            subp(neigh(i)).Objective = ind.Objective;
            subp(neigh(i)).Constraint_Violation = ind_CV;
            subp(neigh(i)).utility = 1;
            flag = true;
            nr_count = nr_count + 1;
        end
    elseif sum(ind_CV1) < sum(subp_i_CV1)
         subp(neigh(i)).Solution = ind.Solution;
         subp(neigh(i)).Objective = ind.Objective;
         subp(neigh(i)).Constraint_Violation = ind_CV;
         subp(neigh(i)).utility = 1;
         flag = true;
         nr_count = nr_count + 1;
    end
    if nr_count > params.nr
        break
    else continue
    end
end
end
