function [ subproblems, pareto_front_EP, pareto_set_EP, evol_subpobj, evol_subpx ] = Epsilon_Constraint( mop, params, subproblems, truePF )
%Main function for the DMOEA-epsilonC
%minimization problem
%input�� mop.name .objnum .solnum .domain; 
%input: params.Iteration .niche .nr  .deta .CR .MR .DRA_interval .mainobj_interval .EP_size .type(type==1 means test problems used in MOEA/D,==2 means test problems used in CEC09, ==3 means test problems used in SMEA��
%output��"subproblems" represents the final evolve population, "pareto_front_EP" and "pareto_set_EP"  represent the PF and PS, respectively.

global idealpoint nadirpoint 
% %%%%%%%%%%%%%%%%%%%%%% idealpoint and nadirpoint %%%%%%%%%%%%%%%%%%%%%%%
 idealpoint = ones(mop.objnum, 1) * inf;
 nadirpoint = ones(mop.objnum, 1) * (-inf);
%%%%%%%%%%%%%%%%%%%%%% idealpoint and nadirpoint %%%%%%%%%%%%%%%%%%%%%%%

%initialization
[ subproblems, EP ] = corresponding_init( mop ,params, subproblems );
a = [subproblems.Objective];
b = [subproblems.Solution];
evol_subpobj(:,:,1) = a;
evol_subpx(:,:,1) = b;

nnn = 1;   %counter of the main objective alternation strategy
params.popsize = length(subproblems);
params.EP_size = ceil(1.5 * params.popsize);

nn = 1;   %record the objective values and solutions of current population every 10 iterations

starttime = clock;
itr_count = 1;  %iteration counter
I = [1 : length(subproblems)];
while itr_count <= params.Iteration
      tic;
     %%%% DRA %%%%%%
      if mod(itr_count, params.DRA_interval) == 1
        main_obj_index = mop.main_obj_index;
        constraint_index = mop.constraint_index;
        temp1 = [subproblems.Objective];
        old1 = temp1(main_obj_index,:) + 10^(-6) * sum(temp1(constraint_index, :));
      end
    if mod(itr_count, params.DRA_interval) == 0
        main_obj_index = mop.main_obj_index;
        constraint_index = mop.constraint_index;
        temp2 = [subproblems.Objective];
        new1 = temp2(main_obj_index, :) + 10^(-6) * sum(temp2(constraint_index, :));
        
        I = DRA_utility(subproblems, old1, new1);   %allocation of resource DRA
        clear old1 new1
    end
      %%%% DRA %%%%%%
      
      %%%%%% main objective alternation strategy %%%%%%
      if mod(itr_count, params.mainobj_interval) == 0
          nnn = nnn + 1;
          index = mod(nnn,mop.objnum);
          if index == 0
              index = mop.objnum;
          end          
          new_main_obj_index = index;
          old_main_obj_index = mop.main_obj_index;
          
          if new_main_obj_index ~= old_main_obj_index
              mop.main_obj_index = new_main_obj_index;
              mop.constraint_index = setdiff([1 : mop.objnum],index);
              constraint_index = mop.constraint_index;
              main_obj_index = mop.main_obj_index;
           
              randsub = randperm(length(subproblems));
              ind = subproblems;
              indobj = [ind.Objective];
              for i = 1:length(subproblems)
                  normal_obj = (indobj - repmat(idealpoint,1,length(subproblems))) ./ (repmat(nadirpoint,1,length(subproblems)) - repmat(idealpoint, 1, length(subproblems)));
                  temp1 = normal_obj(constraint_index, :) - repmat(subproblems(randsub(i)).Epsilon, 1, length(subproblems));
                                    
                  %%%%%%%%%%%%%%%% Solution-to-Subproblem Matching %%%%%%%%%%%%%%%%%%%%%%%
                  temp = abs(temp1);
                  temp_i_CV = sum(temp, 1);
                  [min_i_CV, index1] = min(temp_i_CV);
                  %%%%%%%%%%%%%%%% Solution-to-Subproblem Matching %%%%%%%%%%%%%%%%%%%%%%%                

                  subproblems(randsub(i)).Solution = ind(index1).Solution;
                  subproblems(randsub(i)).Objective = ind(index1).Objective;
                  subproblems(randsub(i)).Constraint_Violation = temp1(:, index1);
                  subproblems(i).utility = 1;
                  ind(index1).Objective = ones(mop.objnum,1) * inf;
                  indobj = [ind.Objective];
                  clear temp1 index1
              end
          end
       end
      %%%%%% main objective alternation strategy %%%%%%

     %%%% EVOLVE %%%%%%
    [subproblems, EP] = evolve(subproblems, EP, mop, params, I); 
    
    if mod(itr_count,10) == 0
        a = [subproblems.Objective];
        b = [subproblems.Solution];
        evol_subpobj(:, :, nn + 1) = a;
        evol_subpx(:, :, nn + 1) = b;
        nn = nn + 1;
    end
    
    itr_count = itr_count + 1;
    a = EP';
    a1 = unique(a,'rows');
    EP = a1';

     if mod(itr_count, 1000) == 0  %params.mainobj_interval
        disp(sprintf('iteration %u finished, time used: %u', itr_count, toc));  
     end    
end
%%%%%%%%% Figure %%%%%%%%%%%%%%%
  figure(1)
 if size(truePF,2) == 2
     plot(EP(mop.solnum+1,:), EP(mop.solnum + mop.objnum,:),'ro')
    xlabel('f1')
    ylabel('f2')
elseif size(truePF,2) == 3
     plot3(EP(mop.solnum+1,:), EP(mop.solnum + 2, :), EP(mop.solnum + mop.objnum, :), 'ro')    
     xlim([0 1])
     ylim([0 1])
     zlim([0 1])
     xlabel('f1')
     ylabel('f2')
     zlabel('f3')
 end
title('EP')
plot3(EP(mop.solnum + 1, :), EP(mop.solnum + 2, :), EP(mop.solnum + mop.objnum, :), 'ro')

%%%%%%%% EP %%%%%%%%%%%%%%%
pareto_set_EP = EP(1 : mop.solnum,:);
pareto_front_EP = EP(mop.solnum + 1 : mop.solnum + mop.objnum, :);
disp(sprintf('total time used %u', etime(clock, starttime)));

end

function [subproblems, EP] = corresponding_init( mop, params, subproblems )
global idealpoint nadirpoint

params.popsize = length(subproblems);
params.EP_size = params.popsize;
ind = randompoint( mop, params.popsize, params.type );  %initialize ind.Solution and ind.Ojbective
 
indobj = [ind.Objective];
%%%%%%%%%%%%%%%%%%%%%%% update idealpoint and nadirpoint%%%%%%%%%%%%%%%%%%%%%%%
idealpoint = min( idealpoint, min(indobj, [], 2 ));  %update idealpoint

[EP, ~] = non_dominated_sort_continue(ind, mop);
EPobj = EP(mop.solnum+1:mop.solnum+mop.objnum, :);
 nadirpoint = max(EPobj, [], 2);  %update nadirpoint
%%%%%%%%%%%%%%%%%%%%%%% update idealpoint and nadirpoint%%%%%%%%%%%%%%%%%%%%%%%
 
randsub = randperm(length(subproblems));
main_obj_index = mop.main_obj_index;
constraint_index = mop.constraint_index;

for i = 1:length(subproblems)
     normal_obj = (indobj - repmat(idealpoint, 1, length(subproblems))) ./(repmat(nadirpoint,1,length(subproblems)) - repmat(idealpoint, 1, length(subproblems)));
    temp1 = normal_obj(constraint_index, :) - repmat(subproblems(randsub(i)).Epsilon, 1, length(subproblems));
    
%%%%%%%%%%%%%%%%Solution-to-Subproblem Matching %%%%%%%%%%%%%%%%%%%%%%%
    temp = abs(temp1);
    temp_i_CV = sum(temp, 1);
    [min_i_CV, index1] = min(temp_i_CV);
%%%%%%%%%%%%%%%%Solution-to-Subproblem Matching %%%%%%%%%%%%%%%%%%%%%%%

    subproblems(randsub(i)).Solution = ind(index1).Solution;
    subproblems(randsub(i)).Objective = ind(index1).Objective;
    subproblems(randsub(i)).Constraint_Violation = temp1(:, index1);
    subproblems(i).utility = 1;
    ind(index1).Objective = ones(mop.objnum,1) * inf;
    indobj = [ind.Objective];
clear temp1 index1
end
end

function [subproblems, EP] = evolve( subproblems, EP, mop, params, I )
main_obj_index = mop.main_obj_index;
constraint_index = mop.constraint_index;

global idealpoint nadirpoint
allEpsilon = [subproblems.Epsilon];
for p = 1:length(I)    
    i = I(p);
%     ind = genetic_op_DEcrossover_PM( subproblems, mop, i, params );  %UF and Lz
    ind = genetic_op_DEcrossover_Gaussianmutation( subproblems, mop, i, params );  %ZDT, DTLZ, and WFG

    idealpoint = min(idealpoint, ind.Objective);   %update ideal point  
    ind_temp = (ind.Objective - idealpoint) ./ (nadirpoint - idealpoint);

    %%%%%%%%%%%%%% Subproblem-to-Solution Matching %%%%%%%%%%%%%%%%%%%
    allEpsilon_ind_0_1 = allEpsilon - repmat(ind_temp(2 : end), 1, length(subproblems));
    allEpsilon_ind_0_1(allEpsilon_ind_0_1 < 0) = inf; 
    sum_allEpsilon_ind_0_1 = sum(allEpsilon_ind_0_1, 1);
    [min_sum_allEpsilon_ind_0_1 index1] = min(sum_allEpsilon_ind_0_1);
    k = index1;
    %%%%%%%%%%%%%%Subproblem-to-Solution Matching %%%%%%%%%%%%%%%%%%%
    
    % %%%%%%%%%%%%%%%% neighborhood update  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
     neigh = subproblems(k).Neighbour;
    [subproblems, flag] = neigbhood_update_FR( subproblems, ind, neigh, params, mop );
   % %%%%%%%%%%%%%%%% neighborhood update  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 

        EP = update_EP(ind, EP, mop, params);  %update EP
        b0 = EP(mop.solnum + 1: mop.solnum + mop.objnum, :);
        nadirpoint = max(b0, [], 2);  %update nadir point
end
end

function [nondominated_front, subp] = non_dominated_sort_continue(subp, mop)
subpobj = [subp.Objective];
subpsolu = [subp.Solution];
f = [subpsolu' subpobj'];
f = [f zeros(size(f,1),1)];
for i = 1:size(f,1)   
    for j = 1:size(f,1)
        dominate_index = dominate_judge( f(i, mop.solnum + 1 : mop.solnum + mop.objnum), f(j,mop.solnum + 1 : mop.solnum + mop.objnum), mop );
        if dominate_index == -1  %f(j,:) dominate f(i,:);
            f(i, end) = 1;
            break
        else
            continue
        end
    end
end
index = find(f(:, end) == 0);
nondominated_front = f(index, 1 : end-1);
nondominated_front = nondominated_front';
end            


function EP = update_EP( ind, EP, mop, params )
a1 = unique(EP', 'rows');
EP = a1';
index = zeros(1, size(EP, 2));
for i = 1:size(EP, 2)
    index(i) = dominate_judge(ind.Objective, EP(mop.solnum + 1 : mop.solnum + mop.objnum, i), mop); %1��pf1 dominates pf2��-1��pf2 dominates pf1;0:nondominated
end

index1 = find(index == 1);
n2 = sum(index == -1);

if ~isempty(index1)
     EP(:, index1) = []; %delete
end
if  n2 == 0   
    a_solu = ind.Solution; %add
    a_obj = ind.Objective;
    a = [a_solu ; a_obj];
    EP = [EP a];
end
if size(EP, 2)>params.EP_size
     EP = Farthest_candidate(EP, mop, params);
%     EP = crowding_distance(EP, mop, params);
end
end
