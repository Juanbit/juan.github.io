function child = polynomial_mutation(parent, parent_up, parent_low, eta)
%polynomial mutation(PM)
r = rand;
if r < 0.5
    deta_k = (2 * r)^(1/(1 + eta)) - 1;
else
    deta_k = 1 - (2 * (1 - r))^(1/(1 + eta));
end
child = parent + (parent_up - parent_low).* deta_k;
end