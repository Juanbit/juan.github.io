function fobj = moead_testfun(name)
%ZDT and DTLZ test problems
switch name
        case 'ZDT1'
            fobj = @ZDT1;
        case 'ZDT2'
            fobj = @ZDT2; 
        case 'ZDT3'
            fobj = @ZDT3;  
        case 'ZDT4'
            fobj = @ZDT4;
        case 'ZDT6'
            fobj = @ZDT6;
        case 'DTLZ1'
            fobj = @DTLZ1;
        case 'DTLZ2'
            fobj = @DTLZ2; 
        case 'DTLZ3'
            fobj = @DTLZ3; 
        case 'DTLZ4'
            fobj = @DTLZ4; 
         case 'DTLZ5'
            fobj = @DTLZ5;
        case 'DTLZ6'
            fobj = @DTLZ6; 
        case 'DTLZ7'
            fobj = @DTLZ7; 
        otherwise
            fobj = @ZDT1;
end
end

function y = ZDT1(x)
dim=30;
y=zeros(2,1);
y(1) = x(1);
su = sum(x)-x(1);    
g = 1 + 9 * su / (dim - 1);
y(2) =g*(1 - sqrt(x(1) / g));
clear su g;
end

function y = ZDT2(x)
dim=30;
y=zeros(2,1);
y(1) = x(1);
su = sum(x)-x(1);    
g = 1 + 9 * su / (dim - 1);
y(2) =g*(1 -(x(1) / g)^2);
clear su g;
end

function y = ZDT3(x)
dim=30;
y=zeros(2,1);
y(1) = x(1);
su = sum(x)-x(1);    
g = 1 + 9 * su / (dim - 1);
y(2) =g*(1 -sqrt(x(1)/ g)-x(1)*sin(10*pi*x(1))/g);
clear su g;
end

function y = ZDT4(x)
dim=10;
y=zeros(2,1);
y(1) = x(1); 
temp1=x.^2-10*cos(4*pi*x);
g = 1 + 10*(dim-1)+ sum(temp1(2:end));
y(2) =g*(1 - sqrt(x(1) / g));

% y(2) = x(1); 
% temp1=x.^2-10*cos(4*pi*x);
% g = 1 + 10*(dim-1)+ sum(temp1(2:end));
% y(1) =g*(1 - sqrt(x(1) / g));

clear temp1;
end

function y=ZDT6(x)%n-10
dim=10;
y=zeros(2,1);
y(1) = 1- exp(-4*x(1))* (sin(6*pi*x(1)))^6;
temp1=sum(x(2:end));
g=1+9* (temp1/(dim-1))^0.25;
y(2) =g*(1 - (y(1) / g)^2);
clear temp1
end

function y=DTLZ1(x)
dim=10;
y=zeros(3,1);
temp1=(x-0.5).^2-cos(20*pi*(x-0.5));
g=100*(dim-2)+100*sum(temp1(3:end));
y(1)=(1+g)*x(1)*x(2);%*0.5
y(2)=(1+g)*x(1)*(1-x(2));%*0.5
y(3)=(1+g)*(1-x(1));%*0.5
end

function y=DTLZ2(x)
dim=12;
y=zeros(3,1);
% temp1=x.^2;%[zeros(2,1) ones(2,1); -1*ones(10,1) ones(10,1)]
temp1=(x-0.5).^2;%[zeros(12,1) ones(12,1)]
g=sum(temp1(3:end));
y(1)=(1+g)*cos(x(1)*pi/2)*cos(x(2)*pi/2);
y(2)=(1+g)*cos(x(1)*pi/2)*sin(x(2)*pi/2);
y(3)=(1+g)*sin(x(1)*pi/2);
end


function y=DTLZ3(x)
dim=10;
y=zeros(3,1);
temp1=(x-0.5).^2-cos(20*pi*(x-0.5));
g=100*(dim-2)+100*sum(temp1(3:end));
y(1)=(1+g)*cos(x(1)*pi/2)*cos(x(2)*pi/2);
y(2)=(1+g)*cos(x(1)*pi/2)*sin(x(2)*pi/2);
y(3)=(1+g)*sin(x(1)*pi/2);
end

function y=DTLZ4(x)
dim=12;
alhpa=100;
y=zeros(3,1);
% temp1=x.^2;
temp1=(x-0.5).^2;
g=sum(temp1(3:end));
y(1)=(1+g)*cos(x(1)^alhpa*pi/2)*cos(x(2)^alhpa*pi/2);
y(2)=(1+g)*cos(x(1)^alhpa*pi/2)*sin(x(2)^alhpa*pi/2);
y(3)=(1+g)*sin(x(1)^alhpa*pi/2);
end

function y=DTLZ5(x)
dim=10;
y=zeros(3,1);
temp1=x.^2;
g=sum(temp1(3:end));
xx=x;
xx(2)=(1+2*g*x(2))/(2*(1+g));
y(1)=(1+g)*cos(xx(1)*pi/2)*cos(xx(2)*pi/2);
y(2)=(1+g)*cos(xx(1)*pi/2)*sin(xx(2)*pi/2);
y(3)=(1+g)*sin(xx(1)*pi/2);
end

function y=DTLZ6(x)
% dim=22;
% y=zeros(3,1);
% temp1=x;
% g=sum(temp1(3:end));
% g=1+(9*g)/(22+1-3);
% temp_h=y.*(1+sin(3*pi.*y))/(1+g);
% h=sum(temp_h(1:2));
% h=3-h;
% y(1)=x(1);
% y(2)=x(2);
% y(3)=(1+g)*h;

g=0;h=0; 
y=zeros(3,1);
nobj=3; nvar=10;
for i=nobj:nvar
    g=g+x(i);
end
g=1+(9*g)/(nvar+1-nobj);
for i=1:nobj
    y(i)=x(i);
end
for i=1:nobj
    h=h+(y(i)/(1+g))*(1+sin(3*pi*y(i)));
end
h=nobj-h;
% y(nobj)=(1+g)*h;
y(nobj)=(1+g)*h+26.5089;%26.5086

% dim=10;%[zeros(2,1) ones(2,1);-1*ones(8,1) ones(8,1)]
% y=zeros(3,1);
% y(1)=x(1);
% y(2)=x(2);
% g=sum(x(3:end));
% g=1+9*g/(10-3+1);
% 
% h=x.*(1+sin(3*pi.*x))/(1+g);
% y(3)=(1+g)*(3-sum(h(1:2)));

end

function y=DTLZ7(x)
dim=10;
y=zeros(3,1);
temp1=x;
g=sum(temp1(3:end));
g=1+(9*g)/(10+1-3);

y(1)=x(1);
y(2)=x(2);

h=(y.*(1+sin(3*pi.*y)))./(1+g);
y(3)=(1+g)*(3-sum(h(1:2)));
end