function index = dominate_judge(pf1, pf2, mop)
%Judge the domination relationship between pf1 and pf2
% minization problems
% return 1:  pf1 donimate pf2;
% return -1: pf2 donimate pf1;
% return 0:  pf1,pf2 is non donimate;

equal = sum(pf1 == pf2);
 
if sum(pf1 < pf2) == 0 & equal ~= mop.objnum
    index = -1; %pf2 dominate pf1
elseif sum(pf1 > pf2) == 0 & equal ~= mop.objnum
    index = 1; %pf1 dominate pf2
else index = 0;
end
end