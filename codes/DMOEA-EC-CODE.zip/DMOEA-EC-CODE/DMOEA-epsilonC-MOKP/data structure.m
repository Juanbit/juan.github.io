% MOKP_750_2 = 
% 
%     Capacity: [2x1 double]
%      Weight1: [250x1 double]
%      Weight2: [250x1 double]
%      Profit1: [250x1 double]
%      Profit2: [250x1 double]
     
     a1=[MOKP_750_2.Weight1];
     a2=[MOKP_750_2.Weight2];
     a3=[MOKP_750_2.Weight2];
     a4=[MOKP_750_2.Weight2];
     MOKP_750_2.Weight=[a1 a2 a3 a4]';%2*250
     
     b1=[MOKP_750_2.Profit1];
     b2=[MOKP_750_2.Profit2];
     b3=[MOKP_750_2.Profit3];
     b4=[MOKP_750_2.Profit4];
     MOKP_750_2.Profit=[b1 b2 b3 b4]';%2*250
     
     c1=[MOKP_750_2.Capacity];
     MOKP_750_2.Capacity=c1;%2*1
     
     MOKP_750_2.solnum=250;
     MOKP_750_2.objnum=4;
     MOKP_750_2.name='MOKP_750_2';
     
     MOKP_750_2.main_obj_index=1;
     MOKP_750_2.constraint_index=[2 3 4];
          
     MOKP_750_2.idealpoint=-max(upper_bound_750_2_relaxPF,[],1)';
     MOKP_750_2.nadirpoint=-min(upper_bound_750_2_relaxPF,[],1)';
     
     save MOKP_750_2.mat MOKP_750_2
     
     