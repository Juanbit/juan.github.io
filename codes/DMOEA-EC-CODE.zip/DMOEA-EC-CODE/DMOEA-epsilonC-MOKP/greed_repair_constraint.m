function x=greed_repair_constraint(x,weight, mop)
index=find(x==1);
%num_index=length(index);%��profit/weight��С����Ϊ0
Pro=mop.Pro(:,index);
Wei=mop.Wei(:,index);
Pro_over_Wei=Pro./Wei;
wei1=weight(1)*ones(1,size(Pro,2));
wei2=weight(2)*ones(1,size(Pro,2));
wei=[wei1; wei2];
weighted_Pro_over_Wei=wei.*Pro_over_Wei;
sum_weighted_Pro_over_Wei=sum(weighted_Pro_over_Wei);
[sorted_sum_weighted_Pro_over_Wei index1]=sort(sum_weighted_Pro_over_Wei);
x(index(index1(1)))=0;
end

