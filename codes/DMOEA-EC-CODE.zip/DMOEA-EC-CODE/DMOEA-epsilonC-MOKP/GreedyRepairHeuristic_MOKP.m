function x=GreedyRepairHeuristic_MOKP(x,mop,alpha)
global idealpoint nadirpoint
objx=mop.Profit*x;%2*100 100*1 == 2*100

main_objx=objx(mop.main_obj_index);
constraint_objx=objx(mop.constraint_index);
constrait_tempx1=alpha.*(nadirpoint(mop.constraint_index)-idealpoint(mop.constraint_index))+idealpoint(mop.constraint_index);%������
constrait_tempx2=constrait_tempx1-constraint_objx;
constrait_tempx2(constrait_tempx2<0)=inf;
tempx=main_objx - sum(constrait_tempx2);

Wei=mop.Weight;
J=find(x==1);%x=1����Щλ/item
constraint_index=mop.Weight*x > mop.Capacity;
I=find(constraint_index==1);%Υ��Լ������Щknapsak���±�

for j=1:length(J)
    xx=x;
    xx(J(j))=0;
    objxx=mop.Profit*xx;
    WeiI=Wei(I,:);


    main_objxx=objxx(mop.main_obj_index);
    constraint_objxx=objxx(mop.constraint_index);
    constrait_tempxx1=alpha.*(nadirpoint(mop.constraint_index)-idealpoint(mop.constraint_index))+idealpoint(mop.constraint_index);%������
    constrait_tempxx2=constrait_tempxx1-constraint_objxx;
    constrait_tempxx2(constrait_tempxx2<0)=inf;    
    tempxx=main_objxx - sum(constrait_tempxx2);

%     tempx=objx(mop.main_obj_index) - sum( abs( objx(mop.constraint_index)-idealpoint(mop.constraint_index)-alpha'*(nadirpoint(mop.constraint_index)-idealpoint(mop.constraint_index)) ) );
%     tempxx=objxx(mop.main_obj_index) - sum( abs( objxx(mop.constraint_index)-idealpoint(mop.constraint_index)-alpha'*(nadirpoint(mop.constraint_index)-idealpoint(mop.constraint_index)) ) );
    
    K(j)=(tempx-tempxx)/sum(WeiI(:,j));%��ô�о�+�����أ�
%         K(j)=(objx(mop.main_obj_index)-objxx(mop.main_obj_index))/sum(WeiI(:,j));
end
[minK index]=min(K);
x(J(index))=0;
end
        