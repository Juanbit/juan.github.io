function child_1=SingleCrossover_MKOP(x1,x2,mop)
item=mop.solnum;
n1=ceil(rand*item);
if n1<1%SingleCrossover
    n1=1;
elseif n1>item
    n1=item;
end
child_1=[x1(1:n1); x2(n1+1:end)];

% while sum(mop.Weight*child_1 > mop.Capacity)>=1
%     child_1=GreedyRepairHeuristic_MOKP(child_1,mop);
%     itrRepair=itrRepair+1;
%     %child_1=greed_repair_constraint(child_1,lamda, mop)��%���lamdaӦ���Ǹ������Ӧ��Ȩ������
% end

end
