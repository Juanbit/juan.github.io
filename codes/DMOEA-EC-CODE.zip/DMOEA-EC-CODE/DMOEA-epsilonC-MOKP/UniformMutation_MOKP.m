function child_2=UniformMutation_MOKP(child_1,mop)
child_2=child_1;
for i=1:mop.solnum
    if rand<0.01
        child_2(i)=1-child_1(i);
    else
        child_2(i)=child_1(i);
    end
end
% while sum(mop.Weight*child_1 > mop.Capacity)>=1
%     child_1=GreedyRepairHeuristic_MOKP(child_1,mop);
%      itrRepair= itrRepair+1;
% end
end
