function [xx, y, UB_relaxPF, UB_01PF]=upper_bound_MOKP(mop_MOKP,z,Lamada)
% z_250_2=[9898.86;10107.3];
% z_500_2=[20096.5;20494.6];
% z_750_2=[30130.1;30037.2];
% z_250_3=[9981.99;10085.5;9774.19];
% z_500_3=[19705.8;20082.7;20437.2];
% z_750_3=[31197.7;29772.1;30519.4];
% z_250_4=[9801.73;9918.88;10119;9136.37];
% z_500_4=[19825.8;19568;19805.8;19592.3];
% z_750_4=[29872.5;29342.1;30468.6;30025.2];

%Lamada_2
% a1=[0:1/201:1];
% a2=1-a1;
% Lamada_2=[a1;a2];
% save Lamada_2.mat Lamada_2

%MOEA/D 202 Lamada_2=init_Weight( 2,1/201);
%MOEA/D 1326  Lamada_3=init_Weight( 3,1/50);
%MOEA/D 3276  Lamada_4=init_Weight( 4,1/25);
%Lamadaÿһ��Ϊһ��Ȩ��

I = mop_MOKP.solnum;
J = mop_MOKP.objnum;
x = sdpvar(I,1,'full');
alpha = sdpvar(1,1,'full');
%w = rand(J,I);
w = mop_MOKP.Weight;
%p = rand(J,I);
p = mop_MOKP.Profit;
%c = rand(J,1);
c = mop_MOKP.Capacity;
% z = [9898.86;10107.3];
% lamada = [0.2;0.8];
% Lamada=[0.1 0.2;0.9 0.8];
tic 
for i=1:size(Lamada,2)
    lamada = Lamada(:,i);
    Constraints = [alpha >= lamada .* (z - p*x)];
    Constraints = Constraints + [w*x <= c];
    Constraints = Constraints + [0<=x<=1];

    Objective = alpha;
    options=sdpsettings('solver','+Cplex');


    sol = optimize(Constraints,Objective,options);
    % Analyze error flags
    if sol.problem == 0
     % Extract and display value
     xx(i,:) = value(x)';
     UB_relaxPF(i,:)=xx(i,:)*p';
     
     temp=xx(i,:)>=0.5;
     UB_01PF(i,:)=temp*p';
%      AA(:,i)=lamada.*(z-p*x);
     y(i)=value(Objective);
    else
     display('Hmm, something went wrong!');
     sol.info
     yalmiperror(sol.problem)
    end
end 
toc