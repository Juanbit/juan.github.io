[upper_bound_250_2_xx,upper_bound_250_2_y,upper_bound_250_2_relaxPF, upper_bound_250_2_01PF]=upper_bound_MOKP(MOKP_250_2,z_250_2,Lamada_2);
save upper_bound_250_2_xx.mat upper_bound_250_2_xx
save upper_bound_250_2_y.mat upper_bound_250_2_y
save upper_bound_250_2_relaxPF.mat upper_bound_250_2_relaxPF
save upper_bound_250_2_01PF.mat upper_bound_250_2_01PF
figure()

% ��Ŀ�� fixed
MOKP_250_2.main_obj_index=1;
MOKP_250_2.constraint_index=2;
[subproblems_250_2_main1, pareto_front_EP_250_2_main1, pareto_set_EP_250_2_main1]=Epsilon_Constraint_version4_MOKP_fixed(MOKP_250_2, params2, subp_250_2, []);
save subproblems_250_2_main1_fixed.mat subproblems_250_2_main1
save pareto_front_EP_250_2_main1_fixed.mat pareto_front_EP_250_2_main1
save pareto_set_EP_250_2_main1_fixed.mat pareto_set_EP_250_2_main1
hold on
plot(upper_bound_250_2_relaxPF(:,1),upper_bound_250_2_relaxPF(:,2),'ro')
legend('main1 fixed','upper bound')
title('MOKP 250 2')
IGD_f(-pareto_front_EP_250_2_main1_fixed,upper_bound_250_2_relaxPF)

MOKP_250_2.main_obj_index=2;
MOKP_250_2.constraint_index=1;
[subproblems_250_2_main2, pareto_front_EP_250_2_main2_, pareto_set_EP_250_2_main2]=Epsilon_Constraint_version4_MOKP_fixed(MOKP_250_2, params2, subp_250_2, []);
save subproblems_250_2_main2_fixed.mat subproblems_250_2_main2
save pareto_front_EP_250_2_main2_fixed.mat pareto_front_EP_250_2_main2_
save pareto_set_EP_250_2_main2_fixed.mat pareto_set_EP_250_2_main2
hold on
plot(upper_bound_250_2_relaxPF(:,1),upper_bound_250_2_relaxPF(:,2),'ro')
legend('main2 fixed','upper bound')
title('MOKP 250 2')
IGD_f(-pareto_front_EP_250_2_main2_fixed,upper_bound_250_2_relaxPF)


% ��Ŀ�� update
MOKP_250_2.main_obj_index=1;
MOKP_250_2.constraint_index=2;
[subproblems_250_2_main1, pareto_front_EP_250_2_main1, pareto_set_EP_250_2_main1]=Epsilon_Constraint_version4_MOKP(MOKP_250_2, params2, subp_250_2, []);
save subproblems_250_2_main1.mat subproblems_250_2_main1
save pareto_front_EP_250_2_main1.mat pareto_front_EP_250_2_main1
save pareto_set_EP_250_2_main1.mat pareto_set_EP_250_2_main1

MOKP_250_2.main_obj_index=2;
MOKP_250_2.constraint_index=1;
[subproblems_250_2_main2, pareto_front_EP_250_2_main2_, pareto_set_EP_250_2_main2]=Epsilon_Constraint_version4_MOKP(MOKP_250_2, params2, subp_250_2, []);
save subproblems_250_2_main2.mat subproblems_250_2_main2
save pareto_front_EP_250_2_main2.mat pareto_front_EP_250_2_main2_
save pareto_set_EP_250_2_main2.mat pareto_set_EP_250_2_main2


% ��Ŀ�� fixed

% ��Ŀ�� fixed