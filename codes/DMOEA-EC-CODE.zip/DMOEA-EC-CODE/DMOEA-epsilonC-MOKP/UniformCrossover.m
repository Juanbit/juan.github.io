function p=UniformCrossover(p1,p2,mop)
p=p1;
for i=1:mop.solnum
    if rand<0.5
        p(i)=p1(i);
    else
        p(i)=p2(i);
    end
    if rand<0.01
        p(i)=1-p(i);
    end
end
end
    