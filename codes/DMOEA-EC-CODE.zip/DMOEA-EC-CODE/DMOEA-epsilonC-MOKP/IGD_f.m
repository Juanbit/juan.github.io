function IGD=IGD_f(bestobj,true_bestobj)
bestobj=bestobj';
WS=0;
n1=size(bestobj,1);
n2=size(true_bestobj,1);
size(bestobj,2);
for i=1:n2
    for j=1:n1
        if size(bestobj,2)==2
            IGD1(j)=sqrt((true_bestobj(i,WS+1)-bestobj(j,WS+1))^2+(true_bestobj(i,WS+2)-bestobj(j,WS+2))^2);
        elseif size(bestobj,2)==3
            IGD1(j)=sqrt((true_bestobj(i,WS+1)-bestobj(j,WS+1))^2+(true_bestobj(i,WS+2)-bestobj(j,WS+2))^2+(true_bestobj(i,WS+3)-bestobj(j,WS+3))^2);
        elseif size(bestobj,2)==4
            IGD1(j)=sqrt((true_bestobj(i,WS+1)-bestobj(j,WS+1))^2+(true_bestobj(i,WS+2)-bestobj(j,WS+2))^2+(true_bestobj(i,WS+3)-bestobj(j,WS+3))^2+(true_bestobj(i,WS+4)-bestobj(j,WS+4))^2);
        end
        IGD(i)=min(IGD1);
    end
end
IGD=sum(IGD)/n2;