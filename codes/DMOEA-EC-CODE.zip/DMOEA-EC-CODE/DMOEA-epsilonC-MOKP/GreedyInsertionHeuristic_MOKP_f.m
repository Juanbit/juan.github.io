function JJ=GreedyInsertionHeuristic_MOKP_f(x,mop,objindex)

objx=mop.Profit*x;%2*100 100*1 == 2*100

Wei=mop.Weight;
J=find(x==0);%x=1����Щλ/item
constraint_index=mop.Weight*x <= mop.Capacity;
I=find(constraint_index==1);%Υ��Լ������Щknapsak���±�
% for j=1:length(I)
%     xx=x;
%     objxx=mop.Pro*xx;
%     xx(I(j))=0;
%     WeiI=Wei(I,:);
%     K(j)=(objx'*lamda(:,j)-objxx'*lamda(:,j))/sum(WeiI(:,j));
%     %K(j)=(subobjective(lamda(:,j), x', idealpoint, method)-subobjective(lamda(:,j), xx', idealpoint, method))/sum(WeiI(:,j));
% end
for j=1:length(J)
    xx=x;
    xx(J(j))=1;
    objxx=mop.Profit*xx;
    WeiI=Wei(I,:);
%     K(j)=(objx'*lamda-objxx'*lamda)/sum(WeiI(:,j));
    K(j)=(objxx(objindex)-objx(objindex))/sum(WeiI(:,j));
end
% [minK index]=max(K);
% x(J(index))=1;

[sortedK, index]=sort(K,'descend');
JJ=J(index);
end
        