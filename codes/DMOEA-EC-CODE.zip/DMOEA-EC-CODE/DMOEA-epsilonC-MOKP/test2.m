I = MOKP_250_2.solnum;
J = MOKP_250_2.objnum;
x = sdpvar(I,1,'full');
alpha = sdpvar(1,1,'full');;
%w = rand(J,I);
w = MOKP_250_2.Weight;
%p = rand(J,I);
p = MOKP_250_2.Profit;
%c = rand(J,1);
c = MOKP_250_2.Capacity;
z = [9898.86;10107.3];
%lamada = [0.3;0.7];
sdpvar lamda;
Constraints = [alpha >= [lamda;1-lamda] .* (z - p*x)];
Constraints = Constraints + [w*x <= c];
Constraints = Constraints + [0<=x<=1];

Objective = alpha;
options=sdpsettings('solver','+Cplex');

tic 
sol = optimizer(Constraints,Objective,options,lamda,x);

cnt = 1;
for lamda_trial = 0.00:0.005:1
   dd(:,cnt) =  p*sol{lamda_trial};
   cnt = cnt + 1;
end
figure
hold on
for i = 1:cnt-1
    plot(dd(1,i),dd(2,i),'o');
end

% 
% % Analyze error flags
% if sol.problem == 0
%  % Extract and display value
%  x = value(x)';
%  AAA = p*x'
% else
%  display('Hmm, something went wrong!');
%  sol.info
%  yalmiperror(sol.problem)
% end
toc