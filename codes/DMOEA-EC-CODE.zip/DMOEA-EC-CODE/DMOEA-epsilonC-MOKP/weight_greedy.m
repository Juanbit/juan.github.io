function ind=weight_greedy(params,mop)%lamadaһ��һ��
W=mop.Weight;%ÿ��item���ÿ��package��weight objnum*solnum ÿһ��Ϊһ����Ʒ��
P=mop.Profit;%ÿ��item���ÿ��package��profit
C=mop.Capacity;%ÿ��package��capacity ��

lamada=init_Weight( mop.objnum, params.step);
size(lamada)

ind=struct('Solution',[],'Objective',[]);
for i=1:size(lamada,2)
    x=zeros(mop.solnum,1);
    JJ=Weight_GreedyInsertionHeuristic_MOKP(x,mop,lamada(:,i));
    for j=1:length(JJ)
        temp=x;
        temp(JJ(j))=1;
        if sum(W*temp > C)==0
            x(JJ(j))=1;
        else
            x(JJ(j))=0;
        end
    end
    temp_ind(:,i)=x;
    clear JJ
end

for i=1:mop.objnum
    index1=find(lamada(i,:)==1);
    temp_x=temp_ind(:,index1);
    ind(i).Solution=temp_x;
    ind(i).Objective=-P*temp_x;%ÿһ��Ϊһ��Ŀ�꺯��ֵ max ��Ϊ min
    temp_ind(:,index1)=[];
    lamada(:,index1)=[];
end

temp1=randperm(size(temp_ind,2));
temp2=temp1(1:params.popsize-mop.objnum);
for i=1:length(temp2)
    temp_x=temp_ind(:,temp2(i));
    ind(mop.objnum+i).Solution=temp_x;
    ind(mop.objnum+i).Objective=-P*temp_x;%ÿһ��Ϊһ��Ŀ�꺯��ֵ max ��Ϊ min
end
end