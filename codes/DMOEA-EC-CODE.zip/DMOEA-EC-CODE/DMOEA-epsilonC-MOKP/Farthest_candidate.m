function EP=Farthest_candidate(EP,mop,params)
P=EP;%EP-P-accept
P_accept=[];
EPsize=size(EP,2);
D=zeros(EPsize,1);
EP_solu=EP(1:mop.solnum,:);
EP_obj=EP(mop.solnum+1:mop.solnum+mop.objnum,:);
for i=1:mop.objnum
    [max_i_P index1]=max(P(mop.solnum+i,:));
    temp1=P(:,index1);
    P_accept=[P_accept temp1];
    P(:,index1)=[];%ones(mop.solum+mop.objnum,1)*inf;
    D(index1)=[];
    [min_i_P index2]=min(P(mop.solnum+i,:));
    temp2=P(:,index2);
    P_accept=[P_accept temp2];
    P(:,index2)=[];%ones(mop.solum+mop.objnum,1)*inf;
    D(index2)=[];
end
for m=1:size(P,2)
    for n=1:size(P_accept,2)
        dist(n)=norm(P(mop.solnum+1:mop.solnum+mop.objnum,m)-P_accept(mop.solnum+1:mop.solnum+mop.objnum,n),2);
    end
    [min_dist index3]=min(dist);
    D(m)=min_dist;
end
for j=1:params.EP_size-size(P_accept,2)
    [max_D index4]=max(D);%x1
    temp2=P(:,index4);
    P_accept=[P_accept temp2];
    for k=1:size(P,2)%ѡ��index4֮�� �������ľ���
        D(k)=min(D(k),norm(P(mop.solnum+1:mop.solnum+mop.objnum,index4)-P(mop.solnum+1:mop.solnum+mop.objnum,k),2));
    end
    P(:,index4)=[];
    D(index4)=[];
end
EP=P_accept;
end
