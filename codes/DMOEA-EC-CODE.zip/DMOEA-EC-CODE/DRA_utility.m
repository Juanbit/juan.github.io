function I = DRA_utility(subproblems, old, new)
%Compute the utility value for each subproblem
 I = [];
old(old == 0) = 0.01;
deta1 = (old - new) ./ old;
 for i = 1 : length(subproblems) 
     if length(find(subproblems(i).Epsilon == 1)) == 1 | length(find(subproblems(i).Epsilon == 0)) == length(subproblems(i).Epsilon)
         I = [I i];
     end
      %utility
     if deta1(i) > 0.001
         subproblems(i).utility = 1;
     else subproblems(i).utility = (0.95 + 0.05 * deta1(i)/0.001) * subproblems(i).utility;
     end
 end

 Utility = [subproblems.utility];
 objnum = size(subproblems(1).Objective, 1);
 for j = 1 : (round(length(subproblems) / 5) - objnum);
     rs = unidrnd(length(subproblems), 1, 10);  %10-tournament-selection
     temp = Utility(rs);
     [sortUtility index] = sort(temp);
     I = [I rs(index(end))];
 end
end    