You should run Epsilon_Constraint.m on MATLAB(e.g., Matlab R2012b and 2014a both are ok) to see the performance of DMOEA-epsilonC.

Here give an example:

Before running it, you need to import related data: mop_cec1.mat, params_UF1.mat, subproblems_2_600_60.mat, and UF1_truePF.mat

Then the command is as follow:
[subproblems, pareto_front_EP, pareto_set_EP, evol_subpobj, evol_subpx]=Epsilon_Constraint(mop_cec1,params_UF1, subproblems_2_600_60, UF1_truePF);

where "subproblems" represents the final population, "pareto_front_EP" and "pareto_set_EP"  represent the PF and PS, respectively.

Note: For different suites of test problems, different genetic operators should be used. 
###   Test Instances  ###       Operators
####  ZDT DTLZ WFG    ###  DE and Gaussianmutation
###     UF LZ         ###  DE and polynomial mutation (PM)

Best wishes!
If you have any questions on the source codes, please contact Juan Li (00134476@bit.edu.cn)

